	
	
		*********Project Run Requirement***********
-To be able to run the project you need to update the DB credentials to your DB credentials inside
"persistence.xml" file at the following path -> src\main\resources\META-INF
-Main class is src\main\java\com\onica\takehometest -> Book.java
-Run as java Application
		*********Project Prerequisite***********
-Postgres DB
-Maven
-Eclipse console (Notice: you can also use CMD after updating your DB credentials by running the following maven command: clean compile assembly:single)