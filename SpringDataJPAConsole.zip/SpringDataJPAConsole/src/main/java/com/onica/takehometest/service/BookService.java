package com.onica.takehometest.service;

import java.util.List;

import com.onica.takehometest.domain.BookModel;

public interface BookService {

	public List<BookModel> getAllBooks();
	
	public BookModel getBookById(Long id);
	
	public Long createBook(BookModel book);
	
	public void createBookList(List<BookModel> bookList);
	
	public void updateBook(BookModel book);
	
	public List<BookModel> findBookLikeTitle(String title);
}
