package com.onica.takehometest.dataaccess;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import org.springframework.data.repository.query.Param;

import com.onica.takehometest.domain.BookModel;

public interface BookRepository extends CrudRepository<BookModel, Long> {

	@Transactional
	@Modifying
	@Query("update BookModel book set book.title = :title, book.author = :author , book.description = :description "
			+ " where book.id = :id")
	void updateBookById(@Param("title") String title, @Param("author") String author , @Param("description") String description, @Param("id") Long id);
	
	List<BookModel> findByTitleContaining(String title);
}
