package com.onica.takehometest;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.onica.takehometest.appconfig.AppConfig;
import com.onica.takehometest.orchestra.Orchestra;

public class Book {


	public static void main(String[] args) {
		AnnotationConfigApplicationContext appContext = new AnnotationConfigApplicationContext(AppConfig.class);
		Orchestra orchestra = appContext.getBean(Orchestra.class);

		orchestra.mainOrchestra();
		appContext.close();
}
}
