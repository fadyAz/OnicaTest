package com.onica.takehometest.shared.common;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import com.onica.takehometest.domain.BookModel;

public class ReadWriteHelper {

	public List<BookModel> readBookFromFile() throws IOException {
		BookModel retrievedBook = null;
		List<BookModel> retrievedBookList = new ArrayList<>();
		BufferedReader readFile = null;
		File file = null;
		FileReader fr = null;
		try {
			file = new File(Constants.INPUTFILEPATH);
			fr = new FileReader(file);
			readFile = new BufferedReader(fr);
			String line;
			while ((line = readFile.readLine()) != null) {
				String[] split = line.split(",", 3);
				if (split.length != 3) { // Not enough tokens (e.g., empty line) read
					continue;
				}
				retrievedBook = new BookModel();
				retrievedBook.setTitle(split[0]);
				retrievedBook.setAuthor(split[1]);
				retrievedBook.setDescription(split[2]);
				retrievedBookList.add(retrievedBook);
			}
			return retrievedBookList;
		} finally {
			if (readFile != null) {
				readFile.close();
			}
			if (fr != null) {
				fr.close();
			}
		}
	}

	public void writeBookToFile(List<BookModel> bookList) throws IOException {

		File file = new File(Constants.OUTPUTFILEPATH);
		FileWriter fw = new FileWriter(file);
		BufferedWriter bw = new BufferedWriter(fw);

		try {
			if (!file.exists()) {
				file.createNewFile();
			}
			for (BookModel book : bookList) {
				bw.write(book.toString());
				bw.newLine();
			}
		} finally {
			bw.close();
		}
	}
}
