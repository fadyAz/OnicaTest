package com.onica.takehometest.service;

import java.util.List;
import java.util.Optional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.onica.takehometest.dataaccess.BookRepository;
import com.onica.takehometest.domain.BookModel;

@Service("bookService")
public class BookServiceImpl implements BookService {
	@Autowired
	private BookRepository bookRepository;
	
	public List<BookModel> getAllBooks() {
		
		// List all books
		Iterable<BookModel> bookIterator = bookRepository.findAll();
		
		return (List<BookModel>) bookIterator;
	}

	public BookModel getBookById(Long id) {
		
		// Get book by ID
		Optional<BookModel> retrievedBook = bookRepository.findById(id);
		
		return retrievedBook.get();
	}
	
	public Long createBook(BookModel book) {
		BookModel savedBook = bookRepository.save(book);
		
		return savedBook.getId();
	}

	public void createBookList(List<BookModel> bookList) {
		bookRepository.saveAll(bookList);
		
	}
	
	public void updateBook(BookModel book) {
		bookRepository.updateBookById(book.getTitle(), book.getAuthor(), book.getDescription(), book.getId());
	}
	
	public List<BookModel> findBookLikeTitle(String title) {
		return bookRepository.findByTitleContaining(title);
	}
	
}
