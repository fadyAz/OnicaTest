package com.onica.takehometest.orchestra;

import java.io.IOException;
import java.util.List;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.onica.takehometest.Book;
import com.onica.takehometest.domain.BookModel;
import com.onica.takehometest.service.BookServiceImpl;
import com.onica.takehometest.shared.common.ReadWriteHelper;

@Component
public class Orchestra {

	static final Logger logger = Logger.getLogger(Book.class);

	@Autowired
	private BookServiceImpl bookService;

	public void mainOrchestra() {
		ReadWriteHelper readWrite = new ReadWriteHelper();
		try {
			List<BookModel> bookList = readWrite.readBookFromFile();
			bookService.createBookList(bookList);
			logger.warn("Loaded data from file successfully");
		} catch (IOException e) {
			logger.warn("Error While Reading file from Data");
		}
		Scanner scanner = new Scanner(System.in);
		boolean more = true;

		try {
			System.out.println("\n==== Book Manager ==== \n");
			System.out.println("     1) View all books\r\n" + "     2) Add a book\r\n" + "     3) Edit a book\r\n"
					+ "     4) Search for a book\r\n" + "     5) Save and exit\r\n");
			System.out.println("Choose [1-5]:");
			do {
				String selectedOption = scanner.nextLine();

				// Choose Option 1 handling
				if (selectedOption.equals("1")) {
					List<BookModel> retrievedBookList = bookService.getAllBooks();
					logger.warn("==== View Books ==== \n");
					retrievedBookList.forEach(retrievedBook -> logger
							.warn(String.format("     [%s] %s", retrievedBook.getId(), retrievedBook.getTitle())));
					getBookDetails();

				// Choose Option 2 handling
				} else if (selectedOption.equals("2")) {
					logger.warn("==== Add a Books ==== \n");
					BookModel book = new BookModel();
					logger.warn("Please enter the following information:");
					System.out.print("Title: ");
					book.setTitle(scanner.nextLine());
					System.out.print("Author:");
					book.setAuthor(scanner.nextLine());
					System.out.print("Description:");
					book.setDescription(scanner.nextLine());
					Long id = bookService.createBook(book);
					logger.warn(String.format("Book [%s] Saved", id));

				// Choose Option 3 handling
				} else if (selectedOption.equals("3")) {
					List<BookModel> retrievedBookList = bookService.getAllBooks();
					logger.warn("==== Edit a Book ==== \n");
					retrievedBookList.forEach(retrievedBook -> logger
							.warn(String.format("     [%s] %s", retrievedBook.getId(), retrievedBook.getTitle())));
					updateBookById();

				// Choose Option 4 handling
				} else if (selectedOption.equals("4")) {
					logger.warn("==== Search ==== \n");
					logger.warn("Type in one or more keywords to search for\n");
					searchBookByTitle();

				// Choose Option 5 handling
				} else if (selectedOption.equals("5")) {
					saveAndClose();
					logger.warn("Library saved.");
					return;
				} else {
					logger.warn("Wrong Choice");
				}
				System.out.println("\n==== Book Manager ====");
				System.out.println("     1) View all books\r\n" + "     2) Add a book\r\n" + "     3) Edit a book\r\n"
						+ "     4) Search for a book\r\n" + "     5) Save and exit\r\n");
				System.out.println("Choose [1-5]:");
			} while (more);
		} finally {
			scanner.close();
		}

	}

	private void updateBookById() {

		Scanner scanner = new Scanner(System.in);
		boolean more = true;
		BookModel retrievedBook;
		BookModel newBook = new BookModel();
		String selectedOption = null;
		boolean changed = false;
		Long id;
		do {
			System.out.println("\nEnter the book ID of the book you want to edit; to return press <Enter>.");
			System.out.print("\nBook ID: ");
			selectedOption = scanner.nextLine();
			if (selectedOption.trim().equals("")) {
				return;
			}

			System.out.println("\nInput the following information. To leave a field unchanged, hit <Enter>.");
			id = Long.valueOf(selectedOption);
			retrievedBook = bookService.getBookById(id);
			System.out.printf("\n    Title [%s]: ", retrievedBook.getTitle());
			selectedOption = scanner.nextLine();
			if (!selectedOption.trim().equals("")) {
				newBook.setTitle(selectedOption);
				changed = true;
			}
			System.out.printf("    Author [%s]: ", retrievedBook.getAuthor());
			selectedOption = scanner.nextLine();
			if (!selectedOption.trim().equals("")) {
				newBook.setAuthor(selectedOption);
				changed = true;
			}
			System.out.printf("    Description [%s]: ", retrievedBook.getDescription());
			selectedOption = scanner.nextLine();
			if (!selectedOption.trim().equals("")) {
				newBook.setDescription(selectedOption);
				changed = true;
			}
			if (changed) {
				newBook.setId(id);
				bookService.updateBook(newBook);
				logger.warn("Book saved.");

			}
		} while (more);
		scanner.close();

	}

	private void getBookDetails() {

		System.out.println("To view details enter the book ID, to return press <Enter>.");
		Scanner scanner = new Scanner(System.in);
		boolean more = true;
		BookModel retrievedBook;
		String selectedOption = null;
		do {
			selectedOption = scanner.nextLine();
			if (String.valueOf(selectedOption).trim().equals("")) {
				return;
			}
			retrievedBook = bookService.getBookById(Long.valueOf(selectedOption));
			if (retrievedBook != null) {
				System.out.printf("\n    ID: %s", retrievedBook.getId());
				System.out.printf("\n    Title: %s", retrievedBook.getTitle());
				System.out.printf("\n    Author: %s", retrievedBook.getAuthor());
				System.out.printf("\n    Description: %s", retrievedBook.getDescription());
				System.out.println("\nTo view details enter the book ID, to return press <Enter>.");
			} else {
				logger.warn(String.format("No Book found with ID: %s", selectedOption));
			}

		} while (more);
		scanner.close();
	}

	private void searchBookByTitle() {

		System.out.printf("    Search: ");
		Scanner scanner = new Scanner(System.in);
		boolean more = true;
		List<BookModel> retrievedBookList;
		String selectedOption = null;
		selectedOption = scanner.nextLine();
		retrievedBookList = bookService.findBookLikeTitle(selectedOption);
		if (retrievedBookList.isEmpty()) {
			logger.warn(String.format("No Book found with Title: %s", selectedOption));
			return;
		} else {
			logger.warn(
					"\nThe following books matched your query. Enter the book ID to see more details, or <Enter> to return.");
			for (BookModel bookModel : retrievedBookList) {
				logger.warn(String.format("    \n[%s] %s", bookModel.getId(), bookModel.getTitle()));
			}
			do {
				System.out.printf("\nBook ID: ");
				selectedOption = scanner.nextLine();
				if (selectedOption.trim().equals("")) {
					return;
				} else {
					BookModel retrievedBook = bookService.getBookById(Long.valueOf(selectedOption));
					System.out.printf("\n    ID: %s", retrievedBook.getId());
					System.out.printf("\n    Title: %s", retrievedBook.getTitle());
					System.out.printf("\n    Author: %s", retrievedBook.getAuthor());
					System.out.printf("\n    Description: %s", retrievedBook.getDescription());
				}

			} while (more);
			scanner.close();
		}
	}

	private void saveAndClose() {
		List<BookModel> bookList = bookService.getAllBooks();
		ReadWriteHelper readWrite = new ReadWriteHelper();
		try {
			readWrite.writeBookToFile(bookList);
		} catch (IOException e) {
			logger.warn("Error While Reading file from DB and saving to File");
		}
	}
}