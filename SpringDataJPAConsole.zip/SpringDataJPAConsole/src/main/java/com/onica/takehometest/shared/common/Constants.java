package com.onica.takehometest.shared.common;

public class Constants {

	private Constants() {

    }
	
	public static final String OUTPUTFILEPATH = "src/main/resources/outputData.txt";
	public static final String INPUTFILEPATH = "src/main/resources/inputData.txt";
}
